--
-- PostgreSQL database dump
--

\restrict IkBvJlW0V6CyZaSWXTKMVAdfsLaHqCooSQ6TGFNmpl9HQ8msTMVp32ACBZJWK0F

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.areas (
    id bigint NOT NULL,
    area_name character varying(100) NOT NULL,
    area_code character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by bigint,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


--
-- Name: areas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.areas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.areas_id_seq OWNED BY public.areas.id;


--
-- Name: cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


--
-- Name: collection_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collection_tasks (
    id bigint NOT NULL,
    visit_plan_id bigint,
    customer_id bigint NOT NULL,
    salesman_id bigint NOT NULL,
    operational_date date NOT NULL,
    total_outstanding_snapshot numeric(15,2) NOT NULL,
    priority character varying(10) DEFAULT 'NORMAL'::character varying NOT NULL,
    result_notes text,
    status character varying(20) DEFAULT 'PLANNED'::character varying NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(0) without time zone
);


--
-- Name: collection_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.collection_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: collection_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.collection_tasks_id_seq OWNED BY public.collection_tasks.id;


--
-- Name: credit_override_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_override_requests (
    id bigint NOT NULL,
    sales_order_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    outstanding_at_request numeric(15,2) NOT NULL,
    order_amount numeric(15,2) NOT NULL,
    credit_limit_at_request numeric(15,2) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    requested_by bigint NOT NULL,
    requested_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    rejected_by bigint,
    rejected_at timestamp(0) without time zone,
    approval_notes text
);


--
-- Name: credit_override_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.credit_override_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: credit_override_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.credit_override_requests_id_seq OWNED BY public.credit_override_requests.id;


--
-- Name: customer_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_return_items (
    id bigint NOT NULL,
    customer_return_id bigint NOT NULL,
    product_id bigint NOT NULL,
    qty numeric(15,3) NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    CONSTRAINT chk_return_item_qty_positive CHECK ((qty > (0)::numeric))
);


--
-- Name: customer_return_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_return_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_return_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_return_items_id_seq OWNED BY public.customer_return_items.id;


--
-- Name: customer_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_returns (
    id bigint NOT NULL,
    document_number character varying(30) NOT NULL,
    invoice_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    salesman_id bigint NOT NULL,
    reason character varying(20) NOT NULL,
    photo_media_id bigint,
    total_amount numeric(15,2) NOT NULL,
    refund_type character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'PENDING_APPROVAL'::character varying NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    rejected_by bigint,
    rejected_at timestamp(0) without time zone,
    approval_notes text,
    refund_processed_by bigint,
    refund_processed_at timestamp(0) without time zone
);


--
-- Name: customer_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_returns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_returns_id_seq OWNED BY public.customer_returns.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id bigint NOT NULL,
    customer_code character varying(30) NOT NULL,
    customer_name character varying(100) NOT NULL,
    address text NOT NULL,
    area_id bigint NOT NULL,
    customer_type character varying(10) NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    latitude numeric(10,7),
    longitude numeric(10,7),
    radius_tolerance_meter integer,
    credit_limit numeric(15,2),
    credit_term_days smallint,
    owner_name character varying(100),
    owner_phone character varying(20),
    owner_nik character varying(20),
    owner_name_ktp character varying(100),
    owner_address_ktp text,
    requested_by bigint NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    rejected_by bigint,
    rejected_at timestamp(0) without time zone,
    approval_notes text,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    CONSTRAINT chk_credit_fields CHECK ((((customer_type)::text = 'CASH'::text) OR (((customer_type)::text = 'CREDIT'::text) AND (credit_limit IS NOT NULL) AND (credit_term_days IS NOT NULL))))
);


--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: daily_cash_reconciliations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_cash_reconciliations (
    id bigint NOT NULL,
    salesman_id bigint NOT NULL,
    operational_date date NOT NULL,
    cash_sales_total numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    collection_cash_total numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    system_total numeric(15,2) NOT NULL,
    actual_received numeric(15,2),
    difference numeric(15,2),
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    discrepancy_notes text,
    reconciled_by bigint,
    reconciled_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: daily_cash_reconciliations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_cash_reconciliations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_cash_reconciliations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_cash_reconciliations_id_seq OWNED BY public.daily_cash_reconciliations.id;


--
-- Name: daily_closings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_closings (
    id bigint NOT NULL,
    operational_date date NOT NULL,
    closed_by bigint NOT NULL,
    closed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    total_salesman_active integer NOT NULL,
    total_visit_skipped integer DEFAULT 0 NOT NULL,
    notes text
);


--
-- Name: daily_closings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_closings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_closings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_closings_id_seq OWNED BY public.daily_closings.id;


--
-- Name: document_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_sequences (
    id bigint NOT NULL,
    document_type character varying(10) NOT NULL,
    operational_date date NOT NULL,
    last_number integer DEFAULT 0 NOT NULL
);


--
-- Name: document_sequences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_sequences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_sequences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_sequences_id_seq OWNED BY public.document_sequences.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id bigint NOT NULL,
    invoice_number character varying(30) NOT NULL,
    sales_order_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    salesman_id bigint NOT NULL,
    customer_name_snapshot character varying(100) NOT NULL,
    customer_address_snapshot text NOT NULL,
    receiver_name character varying(100) NOT NULL,
    invoice_date date NOT NULL,
    due_date date NOT NULL,
    credit_term_days_snapshot smallint NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    paid_amount numeric(15,2) DEFAULT '0'::numeric NOT NULL,
    remaining_amount numeric(15,2) NOT NULL,
    status character varying(20) DEFAULT 'UNPAID'::character varying NOT NULL,
    pdf_media_id bigint,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_invoice_paid CHECK ((paid_amount >= (0)::numeric)),
    CONSTRAINT chk_invoice_remaining CHECK ((remaining_amount >= (0)::numeric))
);


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.media (
    id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL,
    uuid uuid,
    collection_name character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    file_name character varying(255) NOT NULL,
    mime_type character varying(255),
    disk character varying(255) NOT NULL,
    conversions_disk character varying(255),
    size bigint NOT NULL,
    manipulations json NOT NULL,
    custom_properties json NOT NULL,
    generated_conversions json NOT NULL,
    responsive_images json NOT NULL,
    order_column integer,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_permissions (
    permission_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_has_roles (
    role_id bigint NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


--
-- Name: operational_dates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operational_dates (
    id bigint NOT NULL,
    current_date_value date NOT NULL,
    is_closing_in_progress boolean DEFAULT false NOT NULL,
    updated_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: operational_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.operational_dates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: operational_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.operational_dates_id_seq OWNED BY public.operational_dates.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


--
-- Name: payment_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_allocations (
    id bigint NOT NULL,
    payment_id bigint NOT NULL,
    invoice_id bigint NOT NULL,
    allocated_amount numeric(15,2) NOT NULL,
    CONSTRAINT chk_allocated_amount_positive CHECK ((allocated_amount > (0)::numeric))
);


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_allocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_allocations_id_seq OWNED BY public.payment_allocations.id;


--
-- Name: payment_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_receipts (
    id bigint NOT NULL,
    receipt_number character varying(30) NOT NULL,
    payment_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    customer_name_snapshot character varying(100) NOT NULL,
    collector_name_snapshot character varying(100) NOT NULL,
    total_paid numeric(15,2) NOT NULL,
    remaining_after numeric(15,2) NOT NULL,
    receipt_date date NOT NULL,
    qr_payload character varying(500) NOT NULL,
    pdf_media_id bigint,
    downloaded_at timestamp(0) without time zone,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: payment_receipts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_receipts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_receipts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_receipts_id_seq OWNED BY public.payment_receipts.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    payment_number character varying(30) NOT NULL,
    customer_id bigint NOT NULL,
    collected_by bigint NOT NULL,
    visit_plan_id bigint,
    operational_date date NOT NULL,
    payment_method character varying(10) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    notes text,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    idempotency_key uuid,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    posted_by bigint,
    posted_at timestamp(0) without time zone,
    void_by bigint,
    void_at timestamp(0) without time zone,
    void_reason text,
    CONSTRAINT chk_payment_amount_positive CHECK ((total_amount > (0)::numeric))
);


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    product_code character varying(30) NOT NULL,
    product_name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    variant character varying(50),
    category character varying(50),
    unit character varying(20) NOT NULL,
    selling_price numeric(15,2) NOT NULL,
    created_by bigint NOT NULL,
    updated_by bigint
);


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_has_permissions (
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sales_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_order_items (
    id bigint NOT NULL,
    sales_order_id bigint NOT NULL,
    product_id bigint NOT NULL,
    qty numeric(15,3) NOT NULL,
    unit_price numeric(15,2) NOT NULL,
    subtotal numeric(15,2) NOT NULL,
    CONSTRAINT chk_so_item_qty_positive CHECK ((qty > (0)::numeric))
);


--
-- Name: sales_order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_order_items_id_seq OWNED BY public.sales_order_items.id;


--
-- Name: sales_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_orders (
    id bigint NOT NULL,
    document_number character varying(30) NOT NULL,
    visit_plan_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    salesman_id bigint NOT NULL,
    operational_date date NOT NULL,
    payment_type character varying(10) NOT NULL,
    subtotal numeric(15,2) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    receiver_name character varying(100),
    requires_override boolean DEFAULT false NOT NULL,
    override_status character varying(20),
    idempotency_key uuid,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by bigint,
    updated_at timestamp(0) without time zone,
    posted_by bigint,
    posted_at timestamp(0) without time zone,
    cancelled_by bigint,
    cancelled_at timestamp(0) without time zone,
    cancel_reason text,
    void_by bigint,
    void_at timestamp(0) without time zone,
    void_reason text
);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sales_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sales_orders_id_seq OWNED BY public.sales_orders.id;


--
-- Name: salesman_areas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salesman_areas (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    area_id bigint NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: salesman_areas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salesman_areas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salesman_areas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salesman_areas_id_seq OWNED BY public.salesman_areas.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text NOT NULL,
    setting_type character varying(20) DEFAULT 'STRING'::character varying NOT NULL,
    description character varying(255),
    updated_by bigint,
    updated_at timestamp(0) without time zone
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: stock_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustments (
    id bigint NOT NULL,
    document_number character varying(30) NOT NULL,
    product_id bigint NOT NULL,
    holder_type character varying(20) NOT NULL,
    holder_id bigint,
    qty numeric(15,3) NOT NULL,
    reason character varying(20) NOT NULL,
    notes text,
    source_context character varying(30) NOT NULL,
    status character varying(20) DEFAULT 'PENDING_APPROVAL'::character varying NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    rejected_by bigint,
    rejected_at timestamp(0) without time zone,
    approval_notes text,
    CONSTRAINT chk_adjustment_qty_positive CHECK ((qty > (0)::numeric))
);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_adjustments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_adjustments_id_seq OWNED BY public.stock_adjustments.id;


--
-- Name: stock_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_balances (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    holder_type character varying(20) NOT NULL,
    holder_id bigint,
    condition character varying(10) NOT NULL,
    qty numeric(15,3) DEFAULT '0'::numeric NOT NULL,
    updated_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_qty_non_negative CHECK ((qty >= (0)::numeric))
);


--
-- Name: stock_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_balances_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_balances_id_seq OWNED BY public.stock_balances.id;


--
-- Name: stock_ledgers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_ledgers (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    holder_type character varying(20) NOT NULL,
    holder_id bigint,
    condition character varying(10) NOT NULL,
    qty numeric(15,3) NOT NULL,
    operational_date date NOT NULL,
    source_type character varying(30) NOT NULL,
    source_id bigint NOT NULL,
    reference_ledger_id bigint,
    notes text,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: stock_ledgers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_ledgers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_ledgers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_ledgers_id_seq OWNED BY public.stock_ledgers.id;


--
-- Name: stock_loading_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_loading_items (
    id bigint NOT NULL,
    stock_loading_id bigint NOT NULL,
    product_id bigint NOT NULL,
    qty numeric(15,3) NOT NULL,
    CONSTRAINT chk_loading_item_qty_positive CHECK ((qty > (0)::numeric))
);


--
-- Name: stock_loading_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_loading_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_loading_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_loading_items_id_seq OWNED BY public.stock_loading_items.id;


--
-- Name: stock_loadings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_loadings (
    id bigint NOT NULL,
    document_number character varying(30) NOT NULL,
    salesman_id bigint NOT NULL,
    operational_date date NOT NULL,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    idempotency_key uuid,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by bigint,
    updated_at timestamp(0) without time zone,
    posted_by bigint,
    posted_at timestamp(0) without time zone,
    cancelled_by bigint,
    cancelled_at timestamp(0) without time zone,
    cancel_reason text
);


--
-- Name: stock_loadings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_loadings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_loadings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_loadings_id_seq OWNED BY public.stock_loadings.id;


--
-- Name: stock_unloading_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_unloading_items (
    id bigint NOT NULL,
    stock_unloading_id bigint NOT NULL,
    product_id bigint NOT NULL,
    qty numeric(15,3) NOT NULL,
    CONSTRAINT chk_unloading_item_qty_positive CHECK ((qty > (0)::numeric))
);


--
-- Name: stock_unloading_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_unloading_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_unloading_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_unloading_items_id_seq OWNED BY public.stock_unloading_items.id;


--
-- Name: stock_unloadings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_unloadings (
    id bigint NOT NULL,
    document_number character varying(30) NOT NULL,
    salesman_id bigint NOT NULL,
    operational_date date NOT NULL,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    posted_by bigint,
    posted_at timestamp(0) without time zone
);


--
-- Name: stock_unloadings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_unloadings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_unloadings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_unloadings_id_seq OWNED BY public.stock_unloadings.id;


--
-- Name: stock_writeoffs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_writeoffs (
    id bigint NOT NULL,
    document_number character varying(30) NOT NULL,
    product_id bigint NOT NULL,
    qty numeric(15,3) NOT NULL,
    reason text NOT NULL,
    status character varying(20) DEFAULT 'PENDING_APPROVAL'::character varying NOT NULL,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    approved_by bigint,
    approved_at timestamp(0) without time zone,
    rejected_by bigint,
    rejected_at timestamp(0) without time zone,
    approval_notes text,
    CONSTRAINT chk_writeoff_qty_positive CHECK ((qty > (0)::numeric))
);


--
-- Name: stock_writeoffs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_writeoffs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_writeoffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_writeoffs_id_seq OWNED BY public.stock_writeoffs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    phone character varying(20),
    role character varying(20) DEFAULT 'SALESMAN'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    current_session_token character varying(255),
    deleted_at timestamp(0) without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: visit_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_plans (
    id bigint NOT NULL,
    salesman_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    operational_date date NOT NULL,
    is_planned boolean DEFAULT true NOT NULL,
    area_id_snapshot bigint NOT NULL,
    visit_schedule_id bigint,
    status character varying(20) DEFAULT 'PLANNED'::character varying NOT NULL,
    created_by bigint,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: visit_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visit_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visit_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visit_plans_id_seq OWNED BY public.visit_plans.id;


--
-- Name: visit_realizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_realizations (
    id bigint NOT NULL,
    visit_plan_id bigint NOT NULL,
    checkin_latitude numeric(10,7),
    checkin_longitude numeric(10,7),
    checkin_accuracy_meter numeric(8,2),
    checkin_at timestamp(0) without time zone,
    gps_unavailable boolean DEFAULT false NOT NULL,
    gps_low_accuracy boolean DEFAULT false NOT NULL,
    photo_media_id bigint,
    checkout_latitude numeric(10,7),
    checkout_longitude numeric(10,7),
    checkout_at timestamp(0) without time zone,
    idempotency_key uuid,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: visit_realizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visit_realizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visit_realizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visit_realizations_id_seq OWNED BY public.visit_realizations.id;


--
-- Name: visit_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visit_schedules (
    id bigint NOT NULL,
    salesman_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    day_of_week smallint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    effective_from date NOT NULL,
    effective_to date,
    created_by bigint NOT NULL,
    created_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by bigint,
    updated_at timestamp(0) without time zone,
    CONSTRAINT chk_day_of_week CHECK (((day_of_week >= 1) AND (day_of_week <= 7)))
);


--
-- Name: visit_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.visit_schedules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: visit_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.visit_schedules_id_seq OWNED BY public.visit_schedules.id;


--
-- Name: areas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas ALTER COLUMN id SET DEFAULT nextval('public.areas_id_seq'::regclass);


--
-- Name: collection_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_tasks ALTER COLUMN id SET DEFAULT nextval('public.collection_tasks_id_seq'::regclass);


--
-- Name: credit_override_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_override_requests ALTER COLUMN id SET DEFAULT nextval('public.credit_override_requests_id_seq'::regclass);


--
-- Name: customer_return_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_return_items ALTER COLUMN id SET DEFAULT nextval('public.customer_return_items_id_seq'::regclass);


--
-- Name: customer_returns id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns ALTER COLUMN id SET DEFAULT nextval('public.customer_returns_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: daily_cash_reconciliations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_reconciliations ALTER COLUMN id SET DEFAULT nextval('public.daily_cash_reconciliations_id_seq'::regclass);


--
-- Name: daily_closings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_closings ALTER COLUMN id SET DEFAULT nextval('public.daily_closings_id_seq'::regclass);


--
-- Name: document_sequences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_sequences ALTER COLUMN id SET DEFAULT nextval('public.document_sequences_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: operational_dates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_dates ALTER COLUMN id SET DEFAULT nextval('public.operational_dates_id_seq'::regclass);


--
-- Name: payment_allocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations ALTER COLUMN id SET DEFAULT nextval('public.payment_allocations_id_seq'::regclass);


--
-- Name: payment_receipts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts ALTER COLUMN id SET DEFAULT nextval('public.payment_receipts_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sales_order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_order_items ALTER COLUMN id SET DEFAULT nextval('public.sales_order_items_id_seq'::regclass);


--
-- Name: sales_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders ALTER COLUMN id SET DEFAULT nextval('public.sales_orders_id_seq'::regclass);


--
-- Name: salesman_areas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salesman_areas ALTER COLUMN id SET DEFAULT nextval('public.salesman_areas_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: stock_adjustments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments ALTER COLUMN id SET DEFAULT nextval('public.stock_adjustments_id_seq'::regclass);


--
-- Name: stock_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_balances ALTER COLUMN id SET DEFAULT nextval('public.stock_balances_id_seq'::regclass);


--
-- Name: stock_ledgers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledgers ALTER COLUMN id SET DEFAULT nextval('public.stock_ledgers_id_seq'::regclass);


--
-- Name: stock_loading_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loading_items ALTER COLUMN id SET DEFAULT nextval('public.stock_loading_items_id_seq'::regclass);


--
-- Name: stock_loadings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings ALTER COLUMN id SET DEFAULT nextval('public.stock_loadings_id_seq'::regclass);


--
-- Name: stock_unloading_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloading_items ALTER COLUMN id SET DEFAULT nextval('public.stock_unloading_items_id_seq'::regclass);


--
-- Name: stock_unloadings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloadings ALTER COLUMN id SET DEFAULT nextval('public.stock_unloadings_id_seq'::regclass);


--
-- Name: stock_writeoffs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_writeoffs ALTER COLUMN id SET DEFAULT nextval('public.stock_writeoffs_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: visit_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans ALTER COLUMN id SET DEFAULT nextval('public.visit_plans_id_seq'::regclass);


--
-- Name: visit_realizations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_realizations ALTER COLUMN id SET DEFAULT nextval('public.visit_realizations_id_seq'::regclass);


--
-- Name: visit_schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_schedules ALTER COLUMN id SET DEFAULT nextval('public.visit_schedules_id_seq'::regclass);


--
-- Data for Name: areas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.areas (id, area_name, area_code, is_active, created_by, created_at, updated_by, updated_at, deleted_at) FROM stdin;
1	Jakarta Barat	JKT-BAR	t	1	2026-06-26 09:39:38	\N	\N	\N
2	Jakarta Selatan	JKT-SEL	t	1	2026-06-26 09:39:38	\N	\N	\N
3	Jakarta Timur	JKT-TIM	t	1	2026-06-26 09:39:38	\N	\N	\N
4	Jakarta Utara	JKT-UTA	t	1	2026-06-26 09:39:38	\N	\N	\N
5	Jakarta Pusat	JKT-PUS	t	1	2026-06-26 09:39:38	\N	\N	\N
6	Tangerang	TGR	t	1	2026-06-26 09:39:38	\N	\N	\N
7	Bekasi	BKS	t	1	2026-06-26 09:39:38	\N	\N	\N
8	Depok	DPK	t	1	2026-06-26 09:39:38	\N	\N	\N
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: collection_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collection_tasks (id, visit_plan_id, customer_id, salesman_id, operational_date, total_outstanding_snapshot, priority, result_notes, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: credit_override_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_override_requests (id, sales_order_id, customer_id, outstanding_at_request, order_amount, credit_limit_at_request, status, requested_by, requested_at, approved_by, approved_at, rejected_by, rejected_at, approval_notes) FROM stdin;
\.


--
-- Data for Name: customer_return_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_return_items (id, customer_return_id, product_id, qty, unit_price) FROM stdin;
\.


--
-- Data for Name: customer_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_returns (id, document_number, invoice_id, customer_id, salesman_id, reason, photo_media_id, total_amount, refund_type, status, created_by, created_at, approved_by, approved_at, rejected_by, rejected_at, approval_notes, refund_processed_by, refund_processed_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, customer_code, customer_name, address, area_id, customer_type, status, latitude, longitude, radius_tolerance_meter, credit_limit, credit_term_days, owner_name, owner_phone, owner_nik, owner_name_ktp, owner_address_ktp, requested_by, approved_by, approved_at, rejected_by, rejected_at, approval_notes, created_at, updated_at, deleted_at) FROM stdin;
1	CST-001	Warung Bu Sari	Jl. Kebon Jeruk No. 12, Jakarta Barat	1	CASH	ACTIVE	-6.1944000	106.7749000	100	\N	\N	\N	\N	\N	\N	\N	3	1	2026-06-26 09:39:39	\N	\N	\N	2026-06-26 09:39:39	\N	\N
2	CST-002	Toko Berkah Jaya	Jl. Puri Indah No. 45, Jakarta Barat	1	CREDIT	ACTIVE	-6.1876000	106.7463000	150	2000000.00	14	Pak Hendra	081234567890	\N	\N	\N	3	1	2026-06-26 09:39:39	\N	\N	\N	2026-06-26 09:39:39	\N	\N
3	CST-003	Minimarket Sumber Rejeki	Jl. Fatmawati No. 88, Jakarta Selatan	2	CREDIT	ACTIVE	-6.2943000	106.7946000	100	5000000.00	30	Bu Retno	082345678901	\N	\N	\N	3	1	2026-06-26 09:39:39	\N	\N	\N	2026-06-26 09:39:39	\N	\N
4	CST-004	Warung Pak Darto	Jl. Cempaka No. 3, Jakarta Selatan	2	CASH	ACTIVE	-6.2611000	106.8117000	100	\N	\N	\N	\N	\N	\N	\N	3	1	2026-06-26 09:39:39	\N	\N	\N	2026-06-26 09:39:39	\N	\N
5	CST-005	Toko Makmur Sentosa	Jl. Kramat Jati No. 21, Jakarta Timur	3	CREDIT	ACTIVE	-6.2741000	106.8652000	100	3000000.00	14	Pak Sugeng	083456789012	\N	\N	\N	3	1	2026-06-26 09:39:39	\N	\N	\N	2026-06-26 09:39:39	\N	\N
6	CST-006	Warung Mba Yuni	Jl. Pondok Kopi No. 7, Jakarta Timur	3	CASH	ACTIVE	-6.2512000	106.9023000	100	\N	\N	\N	\N	\N	\N	\N	3	1	2026-06-26 09:39:39	\N	\N	\N	2026-06-26 09:39:39	\N	\N
7	CST-020	RKZ	Jl. Raya Diponegoro Surabaya	6	CASH	ACTIVE	-7.2919049	112.7354711	100	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	2026-06-26 09:42:34	2026-06-26 09:42:34	\N
\.


--
-- Data for Name: daily_cash_reconciliations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_cash_reconciliations (id, salesman_id, operational_date, cash_sales_total, collection_cash_total, system_total, actual_received, difference, status, discrepancy_notes, reconciled_by, reconciled_at, created_at) FROM stdin;
\.


--
-- Data for Name: daily_closings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_closings (id, operational_date, closed_by, closed_at, total_salesman_active, total_visit_skipped, notes) FROM stdin;
\.


--
-- Data for Name: document_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_sequences (id, document_type, operational_date, last_number) FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, invoice_number, sales_order_id, customer_id, salesman_id, customer_name_snapshot, customer_address_snapshot, receiver_name, invoice_date, due_date, credit_term_days_snapshot, total_amount, paid_amount, remaining_amount, status, pdf_media_id, created_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.media (id, model_type, model_id, uuid, collection_name, name, file_name, mime_type, disk, conversions_disk, size, manipulations, custom_properties, generated_conversions, responsive_images, order_column, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2026_06_21_191155_create_permission_tables	1
5	2026_06_21_192623_create_media_table	1
6	2026_06_22_030954_modify_users_table_for_sfa_v2	1
7	2026_06_22_032136_create_settings_table	1
8	2026_06_22_032137_create_operational_dates_table	1
9	2026_06_22_032138_create_daily_closings_table	1
10	2026_06_22_032138_create_document_sequences_table	1
11	2026_06_22_032139_create_products_minimal_table	1
12	2026_06_22_032140_create_stock_balances_table	1
13	2026_06_22_032141_create_stock_ledgers_table	1
14	2026_06_22_035528_add_business_columns_to_products_table	1
15	2026_06_22_035529_create_areas_table	1
16	2026_06_22_035529_create_salesman_areas_table	1
17	2026_06_22_091816_create_customers_table	1
18	2026_06_22_094129_create_visit_schedules_table	1
19	2026_06_22_133254_create_stock_loadings_table	1
20	2026_06_22_133255_create_stock_loading_items_table	1
21	2026_06_22_133256_create_stock_unloadings_table	1
22	2026_06_22_133257_create_stock_adjustments_table	1
23	2026_06_22_133257_create_stock_unloading_items_table	1
24	2026_06_22_133258_create_stock_writeoffs_table	1
25	2026_06_23_011453_create_visit_plans_table	1
26	2026_06_23_011454_create_visit_realizations_table	1
27	2026_06_23_060501_create_sales_orders_table	1
28	2026_06_23_060502_create_sales_order_items_table	1
29	2026_06_23_060503_create_credit_override_requests_table	1
30	2026_06_23_060504_create_invoices_table	1
31	2026_06_23_060505_create_customer_returns_table	1
32	2026_06_23_060506_create_customer_return_items_table	1
33	2026_06_23_121106_create_collection_tasks_table	1
34	2026_06_23_121106_create_payments_table	1
35	2026_06_23_121107_create_payment_allocations_table	1
36	2026_06_23_121108_create_daily_cash_reconciliations_table	1
37	2026_06_23_121108_create_payment_receipts_table	1
\.


--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.


--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
1	App\\Models\\User	1
2	App\\Models\\User	2
3	App\\Models\\User	3
\.


--
-- Data for Name: operational_dates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operational_dates (id, current_date_value, is_closing_in_progress, updated_at) FROM stdin;
1	2026-06-26	f	2026-06-26 09:39:27
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: payment_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_allocations (id, payment_id, invoice_id, allocated_amount) FROM stdin;
\.


--
-- Data for Name: payment_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_receipts (id, receipt_number, payment_id, customer_id, customer_name_snapshot, collector_name_snapshot, total_paid, remaining_after, receipt_date, qr_payload, pdf_media_id, downloaded_at, status, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, payment_number, customer_id, collected_by, visit_plan_id, operational_date, payment_method, total_amount, notes, status, idempotency_key, created_by, created_at, posted_by, posted_at, void_by, void_at, void_reason) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
1	customer.view	web	2026-06-26 09:39:34	2026-06-26 09:39:34
2	customer.create	web	2026-06-26 09:39:34	2026-06-26 09:39:34
3	customer.approve	web	2026-06-26 09:39:34	2026-06-26 09:39:34
4	customer.edit	web	2026-06-26 09:39:34	2026-06-26 09:39:34
5	customer.deactivate	web	2026-06-26 09:39:34	2026-06-26 09:39:34
6	product.view	web	2026-06-26 09:39:34	2026-06-26 09:39:34
7	product.manage	web	2026-06-26 09:39:34	2026-06-26 09:39:34
8	area.view	web	2026-06-26 09:39:34	2026-06-26 09:39:34
9	area.manage	web	2026-06-26 09:39:35	2026-06-26 09:39:35
10	visit_schedule.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
11	visit_schedule.manage	web	2026-06-26 09:39:35	2026-06-26 09:39:35
12	user.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
13	user.manage	web	2026-06-26 09:39:35	2026-06-26 09:39:35
14	settings.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
15	settings.manage	web	2026-06-26 09:39:35	2026-06-26 09:39:35
16	stock_loading.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
17	stock_loading.create	web	2026-06-26 09:39:35	2026-06-26 09:39:35
18	stock_loading.post	web	2026-06-26 09:39:35	2026-06-26 09:39:35
19	stock_loading.cancel	web	2026-06-26 09:39:35	2026-06-26 09:39:35
20	stock_unloading.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
21	stock_unloading.create	web	2026-06-26 09:39:35	2026-06-26 09:39:35
22	stock_unloading.post	web	2026-06-26 09:39:35	2026-06-26 09:39:35
23	stock_balance.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
24	stock_adjustment.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
25	stock_adjustment.create	web	2026-06-26 09:39:35	2026-06-26 09:39:35
26	stock_adjustment.approve	web	2026-06-26 09:39:35	2026-06-26 09:39:35
27	customer_return.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
28	customer_return.create	web	2026-06-26 09:39:35	2026-06-26 09:39:35
29	customer_return.approve	web	2026-06-26 09:39:35	2026-06-26 09:39:35
30	customer_return.process_refund	web	2026-06-26 09:39:35	2026-06-26 09:39:35
31	stock_writeoff.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
32	stock_writeoff.create	web	2026-06-26 09:39:35	2026-06-26 09:39:35
33	stock_writeoff.approve	web	2026-06-26 09:39:35	2026-06-26 09:39:35
34	visit_plan.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
35	visit.checkin	web	2026-06-26 09:39:35	2026-06-26 09:39:35
36	visit.checkout	web	2026-06-26 09:39:35	2026-06-26 09:39:35
37	visit.create_unplanned	web	2026-06-26 09:39:35	2026-06-26 09:39:35
38	visit.edit_status_manual	web	2026-06-26 09:39:35	2026-06-26 09:39:35
39	sales_order.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
40	sales_order.create	web	2026-06-26 09:39:35	2026-06-26 09:39:35
41	sales_order.post	web	2026-06-26 09:39:35	2026-06-26 09:39:35
42	sales_order.cancel	web	2026-06-26 09:39:35	2026-06-26 09:39:35
43	sales_order.void	web	2026-06-26 09:39:35	2026-06-26 09:39:35
44	credit_override.request	web	2026-06-26 09:39:35	2026-06-26 09:39:35
45	credit_override.approve	web	2026-06-26 09:39:35	2026-06-26 09:39:35
46	invoice.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
47	invoice.print	web	2026-06-26 09:39:35	2026-06-26 09:39:35
48	collection_task.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
49	collection_task.create_manual	web	2026-06-26 09:39:35	2026-06-26 09:39:35
50	payment.view	web	2026-06-26 09:39:35	2026-06-26 09:39:35
51	payment.create_cash	web	2026-06-26 09:39:35	2026-06-26 09:39:35
52	payment.create_transfer	web	2026-06-26 09:39:36	2026-06-26 09:39:36
53	payment.post	web	2026-06-26 09:39:36	2026-06-26 09:39:36
54	payment.void	web	2026-06-26 09:39:36	2026-06-26 09:39:36
55	payment_receipt.view	web	2026-06-26 09:39:36	2026-06-26 09:39:36
56	payment_receipt.download	web	2026-06-26 09:39:36	2026-06-26 09:39:36
57	cash_reconciliation.view	web	2026-06-26 09:39:36	2026-06-26 09:39:36
58	cash_reconciliation.process	web	2026-06-26 09:39:36	2026-06-26 09:39:36
59	daily_closing.view	web	2026-06-26 09:39:36	2026-06-26 09:39:36
60	daily_closing.execute	web	2026-06-26 09:39:36	2026-06-26 09:39:36
61	dashboard.view_owner	web	2026-06-26 09:39:36	2026-06-26 09:39:36
62	dashboard.view_admin	web	2026-06-26 09:39:36	2026-06-26 09:39:36
63	report.sales	web	2026-06-26 09:39:36	2026-06-26 09:39:36
64	report.stock	web	2026-06-26 09:39:36	2026-06-26 09:39:36
65	report.visit_compliance	web	2026-06-26 09:39:36	2026-06-26 09:39:36
66	report.ar_outstanding	web	2026-06-26 09:39:36	2026-06-26 09:39:36
67	report.collection_risk	web	2026-06-26 09:39:36	2026-06-26 09:39:36
68	report.bad_stock_summary	web	2026-06-26 09:39:36	2026-06-26 09:39:36
69	report.export	web	2026-06-26 09:39:36	2026-06-26 09:39:36
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, product_code, product_name, is_active, created_at, updated_at, deleted_at, variant, category, unit, selling_price, created_by, updated_by) FROM stdin;
1	FLY-ORI-250	Keripik Singkong Falaya	t	2026-06-26 09:39:38	2026-06-26 09:39:38	\N	Original 250gr	Keripik Singkong	pcs	15000.00	1	\N
2	FLY-BAL-250	Keripik Singkong Falaya	t	2026-06-26 09:39:38	2026-06-26 09:39:38	\N	Balado 250gr	Keripik Singkong	pcs	15000.00	1	\N
3	FLY-PED-250	Keripik Singkong Falaya	t	2026-06-26 09:39:38	2026-06-26 09:39:38	\N	Pedas 250gr	Keripik Singkong	pcs	15000.00	1	\N
4	FLY-ORI-500	Keripik Singkong Falaya	t	2026-06-26 09:39:38	2026-06-26 09:39:38	\N	Original 500gr	Keripik Singkong	pcs	28000.00	1	\N
5	FLY-BAL-500	Keripik Singkong Falaya	t	2026-06-26 09:39:38	2026-06-26 09:39:38	\N	Balado 500gr	Keripik Singkong	pcs	28000.00	1	\N
6	FLY-MIX-BOX	Keripik Singkong Falaya	t	2026-06-26 09:39:38	2026-06-26 09:39:38	\N	Mix Box (isi 12 pcs)	Keripik Singkong	box	160000.00	1	\N
\.


--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
1	1
3	1
6	1
8	1
10	1
12	1
14	1
15	1
16	1
20	1
23	1
24	1
26	1
27	1
29	1
31	1
33	1
34	1
39	1
43	1
45	1
46	1
47	1
48	1
50	1
54	1
55	1
57	1
59	1
61	1
63	1
64	1
65	1
66	1
67	1
68	1
69	1
1	2
4	2
5	2
6	2
7	2
8	2
9	2
10	2
11	2
12	2
13	2
14	2
16	2
17	2
18	2
19	2
20	2
21	2
22	2
23	2
24	2
25	2
27	2
30	2
31	2
32	2
34	2
38	2
39	2
43	2
46	2
47	2
48	2
49	2
50	2
52	2
53	2
55	2
56	2
57	2
58	2
59	2
60	2
62	2
63	2
64	2
65	2
66	2
67	2
68	2
69	2
1	3
2	3
6	3
8	3
10	3
16	3
20	3
23	3
27	3
28	3
34	3
35	3
36	3
37	3
39	3
40	3
41	3
42	3
44	3
46	3
48	3
50	3
51	3
53	3
55	3
56	3
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
1	OWNER	web	2026-06-26 09:39:36	2026-06-26 09:39:36
2	ADMIN	web	2026-06-26 09:39:36	2026-06-26 09:39:36
3	SALESMAN	web	2026-06-26 09:39:36	2026-06-26 09:39:36
4	MANAGER	web	2026-06-26 09:39:36	2026-06-26 09:39:36
\.


--
-- Data for Name: sales_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_order_items (id, sales_order_id, product_id, qty, unit_price, subtotal) FROM stdin;
\.


--
-- Data for Name: sales_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_orders (id, document_number, visit_plan_id, customer_id, salesman_id, operational_date, payment_type, subtotal, total_amount, status, receiver_name, requires_override, override_status, idempotency_key, created_by, created_at, updated_by, updated_at, posted_by, posted_at, cancelled_by, cancelled_at, cancel_reason, void_by, void_at, void_reason) FROM stdin;
\.


--
-- Data for Name: salesman_areas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salesman_areas (id, user_id, area_id, effective_from, effective_to, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
u6BacqvSMRDt4NCwPVnZgnkYat3q5slmMB0umN6D	3	114.8.218.252	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoibHV4ekRBMUlSQkI1VHFKWGxiMHJSOWxnYVFEOU4xNEJENU94MTJKZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkvcHdhL3N0b2NrIjtzOjU6InJvdXRlIjtzOjE1OiJwd2EucGFnZXMuc3RvY2siO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=	1782467033
AIfxWvNZW3CZTMz4rls1ddJHbvsx7Y1bQRUpQaly	\N	103.113.73.31	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicEV2R1JZVzVrYmJQRDIwZjFsZHdkTXhRd2E5cm1BYldHOFJ3SlJrRyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkvbG9naW4iO3M6NToicm91dGUiO3M6NToibG9naW4iO319	1782467067
CtpSuMoWoQX3FGVZlCaMUOLTGSHbYAMJgJFh9ewz	\N	103.113.73.31	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoid1kzTmVjU0dMYm55Rnp5UzM5RW84WWxqZk00SlRhVms1eDRLdnMzRyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozOToiaHR0cDovLzEwMy41OS45NC4yMDk6ODA4OS9wd2EvZGFzaGJvYXJkIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkvbG9naW4iO3M6NToicm91dGUiO3M6NToibG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1782467117
gFxfU6xSssNT9CqEX7wBL4eOg2AN3fpRRC0G5Jao	2	114.8.218.252	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiYTlZdWxtbjhRZzhKT1RQTU5SbGcweXJOcWJIMUxTS2d0RUZ5VTQ3WiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkvYWRtaW4vZGFzaGJvYXJkIjtzOjU6InJvdXRlIjtzOjE1OiJhZG1pbi5kYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToyO30=	1782467385
sncafhcj5mXaSUSQ0N9Gxj1SoIPFf1tCEEWZixCj	\N	66.132.172.110	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTE9PZTBRRG9yRlBUdDRsNGk0Q092dGZ6REF6Y3VsUGJjMkRiZzRpWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1782470959
XbcVPOTd9m5xl5ZTHRF7WTJfOOw5qSFXEMJPAKk6	\N	66.132.172.110	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoicmlnOU5ibUwwaFRGZGlUUVpLcGoxeTFWTlR2S2ljSnlkR2IxY1JRNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkvbG9naW4iO3M6NToicm91dGUiO3M6NToibG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1782470962
kifWfNXQcRzp1QGFxcZZgMMaYp3Gm6rbgNwJ5M0H	\N	3.129.187.38	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjRoZGpUUE1xNDZxRm1XYnpUZ1NFYnhkeGtmdzR6R0pOMDFOc0YzMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1782473914
oiumomddT064WmT6gHIBxbBZQhO6iDMLOqz7I3lB	\N	3.129.187.38	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOHA3TWZsTkRqY2VidjRyYkN4OEZWRmJnZWtCU2JLZDM3Vk9yQkQ3OCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkvbG9naW4iO3M6NToicm91dGUiO3M6NToibG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1782473915
W50ac7D7lDoU5A6uT7SyTAH82YiuttpGz2MQx3M9	\N	3.129.187.38	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoieUR6N0lEMmJrWnhzM3lBOU1SVnVwSk9QZGNhSGljTFRzUGVLNkFxOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1782474049
QRGKjPf3BYhWU636rf1BNB8ssG536ERYuEbIuCT8	\N	16.58.56.214	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUWxnamZFamRaWUdHZHlFMWFDRlFHQmxQdDRJQzF4b1JRRlJaSmdGdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1782479423
BFn3R5Ed0hrBpAxZheoYQ7XNnnqJJ4LCCLNnOets	\N	16.58.56.214	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVJNazVkcE02UU9yUUZkSXhySVFWUGtOUkNMUVpXdHdTakt1TnoxZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkvbG9naW4iO3M6NToicm91dGUiO3M6NToibG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1782479424
vWHAGn5GKk2peSj9Wb1V9BArQPw7rbjzNaqIXRvj	\N	16.58.56.214	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZG51SlBDaWlXN0c2RFhjVEY3U01uVjIzZHhOU2Y1Zm4wR1hMS0owUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly8xMDMuNTkuOTQuMjA5OjgwODkiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1782479532
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, setting_key, setting_value, setting_type, description, updated_by, updated_at) FROM stdin;
1	default_radius_tolerance_meter	100	NUMBER	Radius toleransi GPS check-in default (meter)	\N	\N
2	gps_low_accuracy_threshold_meter	100	NUMBER	Threshold akurasi GPS rendah (meter)	\N	\N
3	collection_due_soon_days	3	NUMBER	Jumlah hari sebelum jatuh tempo dianggap DUE_SOON	\N	\N
4	cash_reconciliation_threshold	5000	NUMBER	Toleransi selisih cash reconciliation (Rupiah)	\N	\N
5	company_name	Falaya	STRING	Nama perusahaan untuk invoice/laporan	\N	\N
6	company_address		STRING	Alamat perusahaan untuk invoice/laporan	\N	\N
7	company_logo_url		STRING	URL logo perusahaan	\N	\N
8	company_primary_color	#0d6efd	STRING	Warna utama brand untuk PWA manifest	\N	\N
\.


--
-- Data for Name: stock_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_adjustments (id, document_number, product_id, holder_type, holder_id, qty, reason, notes, source_context, status, created_by, created_at, approved_by, approved_at, rejected_by, rejected_at, approval_notes) FROM stdin;
\.


--
-- Data for Name: stock_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_balances (id, product_id, holder_type, holder_id, condition, qty, updated_at) FROM stdin;
1	1	WAREHOUSE	\N	GOOD	500.000	2026-06-26 09:39:39
2	2	WAREHOUSE	\N	GOOD	500.000	2026-06-26 09:39:39
3	3	WAREHOUSE	\N	GOOD	500.000	2026-06-26 09:39:39
4	4	WAREHOUSE	\N	GOOD	500.000	2026-06-26 09:39:39
5	5	WAREHOUSE	\N	GOOD	500.000	2026-06-26 09:39:39
6	6	WAREHOUSE	\N	GOOD	500.000	2026-06-26 09:39:39
\.


--
-- Data for Name: stock_ledgers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_ledgers (id, product_id, holder_type, holder_id, condition, qty, operational_date, source_type, source_id, reference_ledger_id, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: stock_loading_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_loading_items (id, stock_loading_id, product_id, qty) FROM stdin;
\.


--
-- Data for Name: stock_loadings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_loadings (id, document_number, salesman_id, operational_date, status, idempotency_key, created_by, created_at, updated_by, updated_at, posted_by, posted_at, cancelled_by, cancelled_at, cancel_reason) FROM stdin;
\.


--
-- Data for Name: stock_unloading_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_unloading_items (id, stock_unloading_id, product_id, qty) FROM stdin;
\.


--
-- Data for Name: stock_unloadings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_unloadings (id, document_number, salesman_id, operational_date, status, created_by, created_at, posted_by, posted_at) FROM stdin;
\.


--
-- Data for Name: stock_writeoffs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_writeoffs (id, document_number, product_id, qty, reason, status, created_by, created_at, approved_by, approved_at, rejected_by, rejected_at, approval_notes) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password, created_at, updated_at, phone, role, is_active, current_session_token, deleted_at) FROM stdin;
1	Owner	owner@falaya.test	$2y$12$HS2HcwZweQ58a1woMgret.wy30M/DCChxAaLHlQTEw.2jtlM.ehO.	2026-06-26 09:39:37	2026-06-26 09:39:37	\N	OWNER	t	\N	\N
3	Salesman	salesman@falaya.test	$2y$12$/d9aXByjvXexGUS459BUbOspfuPm9PL5IlXuaSR974tT94HL9h1u6	2026-06-26 09:39:38	2026-06-26 09:43:37	\N	SALESMAN	t	u6BacqvSMRDt4NCwPVnZgnkYat3q5slmMB0umN6D	\N
2	Admin	admin@falaya.test	$2y$12$gXBz9KSVQzuSDV3DgaEgwedpFizm4j1evqitwGdapZf6oMGdHONau	2026-06-26 09:39:37	2026-06-26 09:44:20	\N	ADMIN	t	gFxfU6xSssNT9CqEX7wBL4eOg2AN3fpRRC0G5Jao	\N
\.


--
-- Data for Name: visit_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_plans (id, salesman_id, customer_id, operational_date, is_planned, area_id_snapshot, visit_schedule_id, status, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: visit_realizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_realizations (id, visit_plan_id, checkin_latitude, checkin_longitude, checkin_accuracy_meter, checkin_at, gps_unavailable, gps_low_accuracy, photo_media_id, checkout_latitude, checkout_longitude, checkout_at, idempotency_key, created_at) FROM stdin;
\.


--
-- Data for Name: visit_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visit_schedules (id, salesman_id, customer_id, day_of_week, is_active, effective_from, effective_to, created_by, created_at, updated_by, updated_at) FROM stdin;
1	3	1	1	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
2	3	1	3	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
3	3	1	5	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
4	3	2	1	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
5	3	2	3	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
6	3	2	5	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
7	3	3	2	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
8	3	3	4	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
9	3	4	2	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
10	3	4	4	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
11	3	5	3	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
12	3	5	6	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
13	3	6	3	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
14	3	6	6	t	2026-06-26	\N	1	2026-06-26 09:39:39	\N	\N
\.


--
-- Name: areas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.areas_id_seq', 8, true);


--
-- Name: collection_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.collection_tasks_id_seq', 1, false);


--
-- Name: credit_override_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.credit_override_requests_id_seq', 1, false);


--
-- Name: customer_return_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_return_items_id_seq', 1, false);


--
-- Name: customer_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customer_returns_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customers_id_seq', 7, true);


--
-- Name: daily_cash_reconciliations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_cash_reconciliations_id_seq', 1, false);


--
-- Name: daily_closings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_closings_id_seq', 1, false);


--
-- Name: document_sequences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_sequences_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.media_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 37, true);


--
-- Name: operational_dates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.operational_dates_id_seq', 1, true);


--
-- Name: payment_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_allocations_id_seq', 1, false);


--
-- Name: payment_receipts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_receipts_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 69, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.products_id_seq', 6, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: sales_order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_order_items_id_seq', 1, false);


--
-- Name: sales_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sales_orders_id_seq', 1, false);


--
-- Name: salesman_areas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salesman_areas_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 8, true);


--
-- Name: stock_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_adjustments_id_seq', 1, false);


--
-- Name: stock_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_balances_id_seq', 6, true);


--
-- Name: stock_ledgers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_ledgers_id_seq', 1, false);


--
-- Name: stock_loading_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_loading_items_id_seq', 1, false);


--
-- Name: stock_loadings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_loadings_id_seq', 1, false);


--
-- Name: stock_unloading_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_unloading_items_id_seq', 1, false);


--
-- Name: stock_unloadings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_unloadings_id_seq', 1, false);


--
-- Name: stock_writeoffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_writeoffs_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: visit_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.visit_plans_id_seq', 1, false);


--
-- Name: visit_realizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.visit_realizations_id_seq', 1, false);


--
-- Name: visit_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.visit_schedules_id_seq', 14, true);


--
-- Name: areas areas_area_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT areas_area_code_unique UNIQUE (area_code);


--
-- Name: areas areas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT areas_pkey PRIMARY KEY (id);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: collection_tasks collection_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_tasks
    ADD CONSTRAINT collection_tasks_pkey PRIMARY KEY (id);


--
-- Name: credit_override_requests credit_override_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_override_requests
    ADD CONSTRAINT credit_override_requests_pkey PRIMARY KEY (id);


--
-- Name: customer_return_items customer_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_pkey PRIMARY KEY (id);


--
-- Name: customer_returns customer_returns_document_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_document_number_unique UNIQUE (document_number);


--
-- Name: customer_returns customer_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_pkey PRIMARY KEY (id);


--
-- Name: customers customers_customer_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_customer_code_unique UNIQUE (customer_code);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: daily_cash_reconciliations daily_cash_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_reconciliations
    ADD CONSTRAINT daily_cash_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: daily_closings daily_closings_operational_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_closings
    ADD CONSTRAINT daily_closings_operational_date_unique UNIQUE (operational_date);


--
-- Name: daily_closings daily_closings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_closings
    ADD CONSTRAINT daily_closings_pkey PRIMARY KEY (id);


--
-- Name: document_sequences document_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: invoices invoices_invoice_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_unique UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: media media_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_uuid_unique UNIQUE (uuid);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: operational_dates operational_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operational_dates
    ADD CONSTRAINT operational_dates_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: payment_allocations payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: payment_receipts payment_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_pkey PRIMARY KEY (id);


--
-- Name: payment_receipts payment_receipts_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: payments payments_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: payments payments_payment_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_number_unique UNIQUE (payment_number);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_product_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_code_unique UNIQUE (product_code);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_name_guard_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_guard_name_unique UNIQUE (name, guard_name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sales_order_items sales_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_pkey PRIMARY KEY (id);


--
-- Name: sales_orders sales_orders_document_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_document_number_unique UNIQUE (document_number);


--
-- Name: sales_orders sales_orders_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: sales_orders sales_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_pkey PRIMARY KEY (id);


--
-- Name: salesman_areas salesman_areas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salesman_areas
    ADD CONSTRAINT salesman_areas_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: settings settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: stock_adjustments stock_adjustments_document_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_document_number_unique UNIQUE (document_number);


--
-- Name: stock_adjustments stock_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_pkey PRIMARY KEY (id);


--
-- Name: stock_balances stock_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_balances
    ADD CONSTRAINT stock_balances_pkey PRIMARY KEY (id);


--
-- Name: stock_ledgers stock_ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledgers
    ADD CONSTRAINT stock_ledgers_pkey PRIMARY KEY (id);


--
-- Name: stock_loading_items stock_loading_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loading_items
    ADD CONSTRAINT stock_loading_items_pkey PRIMARY KEY (id);


--
-- Name: stock_loadings stock_loadings_document_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_document_number_unique UNIQUE (document_number);


--
-- Name: stock_loadings stock_loadings_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: stock_loadings stock_loadings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_pkey PRIMARY KEY (id);


--
-- Name: stock_unloading_items stock_unloading_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloading_items
    ADD CONSTRAINT stock_unloading_items_pkey PRIMARY KEY (id);


--
-- Name: stock_unloadings stock_unloadings_document_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloadings
    ADD CONSTRAINT stock_unloadings_document_number_unique UNIQUE (document_number);


--
-- Name: stock_unloadings stock_unloadings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloadings
    ADD CONSTRAINT stock_unloadings_pkey PRIMARY KEY (id);


--
-- Name: stock_writeoffs stock_writeoffs_document_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_writeoffs
    ADD CONSTRAINT stock_writeoffs_document_number_unique UNIQUE (document_number);


--
-- Name: stock_writeoffs stock_writeoffs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_writeoffs
    ADD CONSTRAINT stock_writeoffs_pkey PRIMARY KEY (id);


--
-- Name: daily_cash_reconciliations uq_daily_recon; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_reconciliations
    ADD CONSTRAINT uq_daily_recon UNIQUE (salesman_id, operational_date);


--
-- Name: document_sequences uq_doc_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT uq_doc_sequence UNIQUE (document_type, operational_date);


--
-- Name: payment_allocations uq_payment_invoice; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT uq_payment_invoice UNIQUE (payment_id, invoice_id);


--
-- Name: stock_balances uq_stock_balance; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_balances
    ADD CONSTRAINT uq_stock_balance UNIQUE (product_id, holder_type, holder_id, condition);


--
-- Name: visit_plans uq_visit_plan_per_day; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans
    ADD CONSTRAINT uq_visit_plan_per_day UNIQUE (customer_id, salesman_id, operational_date);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: visit_plans visit_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans
    ADD CONSTRAINT visit_plans_pkey PRIMARY KEY (id);


--
-- Name: visit_realizations visit_realizations_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_realizations
    ADD CONSTRAINT visit_realizations_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: visit_realizations visit_realizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_realizations
    ADD CONSTRAINT visit_realizations_pkey PRIMARY KEY (id);


--
-- Name: visit_schedules visit_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_schedules
    ADD CONSTRAINT visit_schedules_pkey PRIMARY KEY (id);


--
-- Name: cache_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);


--
-- Name: cache_locks_expiration_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);


--
-- Name: idx_areas_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_areas_active ON public.areas USING btree (is_active) WHERE (deleted_at IS NULL);


--
-- Name: idx_collection_tasks_salesman_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_collection_tasks_salesman_date ON public.collection_tasks USING btree (salesman_id, operational_date);


--
-- Name: idx_collection_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_collection_tasks_status ON public.collection_tasks USING btree (operational_date, status);


--
-- Name: idx_credit_override_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_override_pending ON public.credit_override_requests USING btree (status) WHERE ((status)::text = 'PENDING'::text);


--
-- Name: idx_customers_area; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_area ON public.customers USING btree (area_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_customers_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_status ON public.customers USING btree (status) WHERE (deleted_at IS NULL);


--
-- Name: idx_customers_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_type ON public.customers USING btree (customer_type, status);


--
-- Name: idx_invoices_customer_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_customer_status ON public.invoices USING btree (customer_id, status);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date) WHERE ((status)::text <> 'PAID'::text);


--
-- Name: idx_payments_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_customer ON public.payments USING btree (customer_id);


--
-- Name: idx_payments_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_date ON public.payments USING btree (operational_date, payment_method);


--
-- Name: idx_sales_orders_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sales_orders_customer ON public.sales_orders USING btree (customer_id, status);


--
-- Name: idx_sales_orders_salesman_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sales_orders_salesman_date ON public.sales_orders USING btree (salesman_id, operational_date);


--
-- Name: idx_salesman_areas_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_salesman_areas_active ON public.salesman_areas USING btree (user_id, area_id) WHERE (is_active = true);


--
-- Name: idx_stock_adjustments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adjustments_status ON public.stock_adjustments USING btree (status);


--
-- Name: idx_stock_ledgers_balance_calc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_ledgers_balance_calc ON public.stock_ledgers USING btree (product_id, holder_type, holder_id, condition);


--
-- Name: idx_stock_ledgers_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_ledgers_date ON public.stock_ledgers USING btree (operational_date);


--
-- Name: idx_stock_ledgers_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_ledgers_source ON public.stock_ledgers USING btree (source_type, source_id);


--
-- Name: idx_stock_loading_items_loading; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_loading_items_loading ON public.stock_loading_items USING btree (stock_loading_id);


--
-- Name: idx_stock_loadings_salesman_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_loadings_salesman_date ON public.stock_loadings USING btree (salesman_id, operational_date);


--
-- Name: idx_stock_unloading_items_unloading; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_unloading_items_unloading ON public.stock_unloading_items USING btree (stock_unloading_id);


--
-- Name: idx_stock_writeoffs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_writeoffs_status ON public.stock_writeoffs USING btree (status);


--
-- Name: idx_visit_plans_salesman_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_plans_salesman_date ON public.visit_plans USING btree (salesman_id, operational_date);


--
-- Name: idx_visit_plans_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_plans_status ON public.visit_plans USING btree (operational_date, status);


--
-- Name: idx_visit_realizations_plan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_realizations_plan ON public.visit_realizations USING btree (visit_plan_id);


--
-- Name: idx_visit_schedules_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_visit_schedules_lookup ON public.visit_schedules USING btree (day_of_week, is_active, salesman_id) WHERE (is_active = true);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: media_model_type_model_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_model_type_model_id_index ON public.media USING btree (model_type, model_id);


--
-- Name: media_order_column_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX media_order_column_index ON public.media USING btree (order_column);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: uq_one_active_so_per_visit; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_one_active_so_per_visit ON public.sales_orders USING btree (visit_plan_id) WHERE ((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'POSTED'::character varying])::text[]));


--
-- Name: areas areas_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT areas_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: areas areas_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.areas
    ADD CONSTRAINT areas_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: collection_tasks collection_tasks_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_tasks
    ADD CONSTRAINT collection_tasks_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: collection_tasks collection_tasks_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_tasks
    ADD CONSTRAINT collection_tasks_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: collection_tasks collection_tasks_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_tasks
    ADD CONSTRAINT collection_tasks_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: collection_tasks collection_tasks_visit_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collection_tasks
    ADD CONSTRAINT collection_tasks_visit_plan_id_foreign FOREIGN KEY (visit_plan_id) REFERENCES public.visit_plans(id);


--
-- Name: credit_override_requests credit_override_requests_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_override_requests
    ADD CONSTRAINT credit_override_requests_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: credit_override_requests credit_override_requests_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_override_requests
    ADD CONSTRAINT credit_override_requests_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: credit_override_requests credit_override_requests_rejected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_override_requests
    ADD CONSTRAINT credit_override_requests_rejected_by_foreign FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- Name: credit_override_requests credit_override_requests_requested_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_override_requests
    ADD CONSTRAINT credit_override_requests_requested_by_foreign FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: credit_override_requests credit_override_requests_sales_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_override_requests
    ADD CONSTRAINT credit_override_requests_sales_order_id_foreign FOREIGN KEY (sales_order_id) REFERENCES public.sales_orders(id);


--
-- Name: customer_return_items customer_return_items_customer_return_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_customer_return_id_foreign FOREIGN KEY (customer_return_id) REFERENCES public.customer_returns(id);


--
-- Name: customer_return_items customer_return_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_return_items
    ADD CONSTRAINT customer_return_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: customer_returns customer_returns_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: customer_returns customer_returns_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: customer_returns customer_returns_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: customer_returns customer_returns_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: customer_returns customer_returns_refund_processed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_refund_processed_by_foreign FOREIGN KEY (refund_processed_by) REFERENCES public.users(id);


--
-- Name: customer_returns customer_returns_rejected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_rejected_by_foreign FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- Name: customer_returns customer_returns_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_returns
    ADD CONSTRAINT customer_returns_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: customers customers_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: customers customers_area_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_area_id_foreign FOREIGN KEY (area_id) REFERENCES public.areas(id);


--
-- Name: customers customers_rejected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_rejected_by_foreign FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- Name: customers customers_requested_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_requested_by_foreign FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: daily_cash_reconciliations daily_cash_reconciliations_reconciled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_reconciliations
    ADD CONSTRAINT daily_cash_reconciliations_reconciled_by_foreign FOREIGN KEY (reconciled_by) REFERENCES public.users(id);


--
-- Name: daily_cash_reconciliations daily_cash_reconciliations_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_cash_reconciliations
    ADD CONSTRAINT daily_cash_reconciliations_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: daily_closings daily_closings_closed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_closings
    ADD CONSTRAINT daily_closings_closed_by_foreign FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- Name: invoices invoices_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: invoices invoices_sales_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_sales_order_id_foreign FOREIGN KEY (sales_order_id) REFERENCES public.sales_orders(id);


--
-- Name: invoices invoices_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: payment_allocations payment_allocations_invoice_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_invoice_id_foreign FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: payment_allocations payment_allocations_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_payment_id_foreign FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: payment_receipts payment_receipts_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: payment_receipts payment_receipts_payment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_receipts
    ADD CONSTRAINT payment_receipts_payment_id_foreign FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: payments payments_collected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_collected_by_foreign FOREIGN KEY (collected_by) REFERENCES public.users(id);


--
-- Name: payments payments_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: payments payments_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: payments payments_posted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_posted_by_foreign FOREIGN KEY (posted_by) REFERENCES public.users(id);


--
-- Name: payments payments_visit_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_visit_plan_id_foreign FOREIGN KEY (visit_plan_id) REFERENCES public.visit_plans(id);


--
-- Name: payments payments_void_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_void_by_foreign FOREIGN KEY (void_by) REFERENCES public.users(id);


--
-- Name: products products_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: products products_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: sales_order_items sales_order_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: sales_order_items sales_order_items_sales_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_order_items
    ADD CONSTRAINT sales_order_items_sales_order_id_foreign FOREIGN KEY (sales_order_id) REFERENCES public.sales_orders(id);


--
-- Name: sales_orders sales_orders_cancelled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_cancelled_by_foreign FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: sales_orders sales_orders_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: sales_orders sales_orders_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sales_orders sales_orders_posted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_posted_by_foreign FOREIGN KEY (posted_by) REFERENCES public.users(id);


--
-- Name: sales_orders sales_orders_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: sales_orders sales_orders_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: sales_orders sales_orders_visit_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_visit_plan_id_foreign FOREIGN KEY (visit_plan_id) REFERENCES public.visit_plans(id);


--
-- Name: sales_orders sales_orders_void_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_orders
    ADD CONSTRAINT sales_orders_void_by_foreign FOREIGN KEY (void_by) REFERENCES public.users(id);


--
-- Name: salesman_areas salesman_areas_area_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salesman_areas
    ADD CONSTRAINT salesman_areas_area_id_foreign FOREIGN KEY (area_id) REFERENCES public.areas(id);


--
-- Name: salesman_areas salesman_areas_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salesman_areas
    ADD CONSTRAINT salesman_areas_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: salesman_areas salesman_areas_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salesman_areas
    ADD CONSTRAINT salesman_areas_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: settings settings_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: stock_adjustments stock_adjustments_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: stock_adjustments stock_adjustments_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_adjustments stock_adjustments_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_adjustments stock_adjustments_rejected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_rejected_by_foreign FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- Name: stock_balances stock_balances_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_balances
    ADD CONSTRAINT stock_balances_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_ledgers stock_ledgers_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledgers
    ADD CONSTRAINT stock_ledgers_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_ledgers stock_ledgers_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledgers
    ADD CONSTRAINT stock_ledgers_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_ledgers stock_ledgers_reference_ledger_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_ledgers
    ADD CONSTRAINT stock_ledgers_reference_ledger_id_foreign FOREIGN KEY (reference_ledger_id) REFERENCES public.stock_ledgers(id);


--
-- Name: stock_loading_items stock_loading_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loading_items
    ADD CONSTRAINT stock_loading_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_loading_items stock_loading_items_stock_loading_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loading_items
    ADD CONSTRAINT stock_loading_items_stock_loading_id_foreign FOREIGN KEY (stock_loading_id) REFERENCES public.stock_loadings(id);


--
-- Name: stock_loadings stock_loadings_cancelled_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_cancelled_by_foreign FOREIGN KEY (cancelled_by) REFERENCES public.users(id);


--
-- Name: stock_loadings stock_loadings_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_loadings stock_loadings_posted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_posted_by_foreign FOREIGN KEY (posted_by) REFERENCES public.users(id);


--
-- Name: stock_loadings stock_loadings_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: stock_loadings stock_loadings_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_loadings
    ADD CONSTRAINT stock_loadings_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: stock_unloading_items stock_unloading_items_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloading_items
    ADD CONSTRAINT stock_unloading_items_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_unloading_items stock_unloading_items_stock_unloading_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloading_items
    ADD CONSTRAINT stock_unloading_items_stock_unloading_id_foreign FOREIGN KEY (stock_unloading_id) REFERENCES public.stock_unloadings(id);


--
-- Name: stock_unloadings stock_unloadings_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloadings
    ADD CONSTRAINT stock_unloadings_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_unloadings stock_unloadings_posted_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloadings
    ADD CONSTRAINT stock_unloadings_posted_by_foreign FOREIGN KEY (posted_by) REFERENCES public.users(id);


--
-- Name: stock_unloadings stock_unloadings_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_unloadings
    ADD CONSTRAINT stock_unloadings_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: stock_writeoffs stock_writeoffs_approved_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_writeoffs
    ADD CONSTRAINT stock_writeoffs_approved_by_foreign FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: stock_writeoffs stock_writeoffs_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_writeoffs
    ADD CONSTRAINT stock_writeoffs_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: stock_writeoffs stock_writeoffs_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_writeoffs
    ADD CONSTRAINT stock_writeoffs_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: stock_writeoffs stock_writeoffs_rejected_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_writeoffs
    ADD CONSTRAINT stock_writeoffs_rejected_by_foreign FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- Name: visit_plans visit_plans_area_id_snapshot_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans
    ADD CONSTRAINT visit_plans_area_id_snapshot_foreign FOREIGN KEY (area_id_snapshot) REFERENCES public.areas(id);


--
-- Name: visit_plans visit_plans_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans
    ADD CONSTRAINT visit_plans_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: visit_plans visit_plans_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans
    ADD CONSTRAINT visit_plans_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: visit_plans visit_plans_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans
    ADD CONSTRAINT visit_plans_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: visit_plans visit_plans_visit_schedule_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_plans
    ADD CONSTRAINT visit_plans_visit_schedule_id_foreign FOREIGN KEY (visit_schedule_id) REFERENCES public.visit_schedules(id);


--
-- Name: visit_realizations visit_realizations_visit_plan_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_realizations
    ADD CONSTRAINT visit_realizations_visit_plan_id_foreign FOREIGN KEY (visit_plan_id) REFERENCES public.visit_plans(id);


--
-- Name: visit_schedules visit_schedules_created_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_schedules
    ADD CONSTRAINT visit_schedules_created_by_foreign FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: visit_schedules visit_schedules_customer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_schedules
    ADD CONSTRAINT visit_schedules_customer_id_foreign FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: visit_schedules visit_schedules_salesman_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_schedules
    ADD CONSTRAINT visit_schedules_salesman_id_foreign FOREIGN KEY (salesman_id) REFERENCES public.users(id);


--
-- Name: visit_schedules visit_schedules_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visit_schedules
    ADD CONSTRAINT visit_schedules_updated_by_foreign FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict IkBvJlW0V6CyZaSWXTKMVAdfsLaHqCooSQ6TGFNmpl9HQ8msTMVp32ACBZJWK0F

